import pandas as pd

class DoneQuotes:

    def __init__(self, path):
        self.df = pd.read_csv(path, sep=",", header=None, names=['Timestamp', 'CUSIP', 'Price'])

    def __group_cusip_price(self):
        return self.df.groupby('CUSIP')['Price'].max().to_dict()

    def get_resume(self):
        print(self.df.groupby('CUSIP').head())

    def get_ten_largest_profits(self):
        cusip_price_dict = self.__group_cusip_price()

        for index, row in self.df.iterrows():
            delta = cusip_price_dict.get(row['CUSIP']) - row['Price']
            self.df.loc[index, 'Profit'] = delta

        n_dict = self.df.groupby('CUSIP')['Profit'].max()
        largest = n_dict.nlargest(10).to_dict()

        return [f'profit: {value}, CUSIP: {key}' for key, value in largest.items()]



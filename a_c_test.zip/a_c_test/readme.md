## Parse input from stdin.
To use you need to install:
    Python >=3.8 and pip

The solution is a python class for management
the file data input as a data frame.

To use you need to activate the python virtual env.
### LInux
```bash
source venv/bin/activate
```

### Windows
```bash
cd venv/Scripts/
activate.bat
```
### Install requirements
```bash
pip install -r requirements.txt
```
### Price_quote - DoneQuotes class
The solution is in the price quote file.
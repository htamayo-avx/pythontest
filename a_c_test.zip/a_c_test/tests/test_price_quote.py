from price_quote.price_quote import DoneQuotes
import pytest

@pytest.fixture
def price_quote():
    return DoneQuotes('test_quotes-two.txt')


def test_get_ten_largest_profits(price_quote):
    assert price_quote.get_ten_largest_profits() == [
        'profit: 50.0, CUSIP: 38259P508',
        'profit: 2.2700000000000102, CUSIP: 037833100'
    ]
